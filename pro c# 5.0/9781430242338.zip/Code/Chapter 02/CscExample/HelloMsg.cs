// The HelloMessage class
using System;
using System.Windows.Forms;

class HelloMessage
{
  public void Speak()
  {
    MessageBox.Show("Hello...");
  }
}
